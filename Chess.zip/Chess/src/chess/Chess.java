/*
* Mateusz Pawlowski Chess game with computer 2024.
* Computer Chess game programmed in Java. 
*/
package chess;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author M
 */
public class Chess extends JPanel implements Runnable,MouseListener,MouseMotionListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Chess");
    public Thread thread;
    
    public static boolean whiteTurn=true;
    public static boolean computerAgain=false;
    
    public static ArrayList<Pawn> chessboard=new ArrayList<Pawn>();
    
    public int old_mouse_x=0;
    public int old_mouse_y=0;
    
    public Pawn pawn_move=null;
    
    public int cx=0,cy=0;
    
    public int old_cx=0,old_cy=0;
    
    public boolean second_select=false;
    public boolean mouse_clicked=false;
    
    public static int[][] ctable=new int[7][7];
    
    public static int[][] power_table=new int[7][7];
    
    public static int[][] king_table=new int[7][7];;
    
    public static int move_nr=0;
    
    public static int computer_pawns_alive=0;
    
    public static Random rnd=new Random();
    
    public static boolean blackMoves=false;
    public static boolean whiteMoves=false;
    
    Chess()
    {
        
        rnd.setSeed(System.currentTimeMillis());
        
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        
        power_table=new int[][]
        {
            {1,2,3,10,121,3,2,1},
            {1,2,3,121,121,121,2,1},
            {1,2,3,121,121,3,2,1},
            {1,2,3,5,5,3,2,1},
            {1,2,3,5,5,3,2,1},
            {1,2,3,4,4,3,2,1},
            {1,2,3,4,4,3,2,1},
            {1,2,3,4,4,3,2,1}
        };
        
        chessboard.add(new Pawn(3,0,"Queen","Black"));
        chessboard.add(new Pawn(4,0,"King","Black"));
        chessboard.add(new Pawn(1,0,"Knight","Black"));
        chessboard.add(new Pawn(6,0,"Knight","Black"));
        chessboard.add(new Pawn(7,0,"Rook","Black"));
        chessboard.add(new Pawn(0,0,"Rook","Black"));
        chessboard.add(new Pawn(2,0,"Bishop","Black"));
        chessboard.add(new Pawn(5,0,"Bishop","Black"));
        
        chessboard.add(new Pawn(0,1,"Pawn","Black"));
        chessboard.add(new Pawn(1,1,"Pawn","Black"));
        chessboard.add(new Pawn(2,1,"Pawn","Black"));
        chessboard.add(new Pawn(3,1,"Pawn","Black"));
        chessboard.add(new Pawn(4,1,"Pawn","Black"));
        chessboard.add(new Pawn(5,1,"Pawn","Black"));
        chessboard.add(new Pawn(6,1,"Pawn","Black"));
        chessboard.add(new Pawn(7,1,"Pawn","Black"));
        
        
        chessboard.add(new Pawn(0,6,"Pawn","White"));
        chessboard.add(new Pawn(1,6,"Pawn","White"));
        chessboard.add(new Pawn(2,6,"Pawn","White"));
        chessboard.add(new Pawn(3,6,"Pawn","White"));
        chessboard.add(new Pawn(4,6,"Pawn","White"));
        chessboard.add(new Pawn(5,6,"Pawn","White"));
        chessboard.add(new Pawn(6,6,"Pawn","White"));
        chessboard.add(new Pawn(7,6,"Pawn","White"));
        
        chessboard.add(new Pawn(3,7,"Queen","White"));
        chessboard.add(new Pawn(4,7,"King","White"));
        chessboard.add(new Pawn(1,7,"Knight","White"));
        chessboard.add(new Pawn(6,7,"Knight","White"));
        chessboard.add(new Pawn(7,7,"Rook","White"));
        chessboard.add(new Pawn(0,7,"Rook","White"));
        chessboard.add(new Pawn(2,7,"Bishop","White"));
        chessboard.add(new Pawn(5,7,"Bishop","White"));
        
    }
    
    public static void create_king_table()
    {
        king_table=new int[][]
        {
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0}
        };
    }
    
    public static void show_king_table()
    {
        System.out.println("");
        for(int y=0;y<8;y++) {
        for(int x=0;x<8;x++)
        {
        System.out.print(king_table[y][x]);
        }
        System.out.println("");
        }
    }
    
    public void create_table()
    {
        
        ctable=new int[][]
        {
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0}
        };
        
        computer_pawns_alive=0;
        
        for(Pawn p:chessboard)
        {
            if(p.alive==true)
            {
                if(p.isBlack==false) ctable[p.y][p.x]=1;
                if(p.isBlack==true) {ctable[p.y][p.x]=2;computer_pawns_alive++;}
            }
        }
        //System.out.println("computer_pawns_alive "+computer_pawns_alive);
    }
    
    public void show_table()
    {
        System.out.println("");
        for(int y=0;y<8;y++) {
        for(int x=0;x<8;x++)
        {
        System.out.print(this.ctable[y][x]);
        }
        System.out.println("");
        }
    }
    
    public void run() {
        
     while(true){
        try{
            
            cx=(int)(this.old_mouse_x-20)/60;
            cy=(int)(this.old_mouse_y-20)/60;     
            create_table();
            
            if(mouse_clicked)
            {
                create_table();
                //show_table();
                check_mouse();
                
                create_table();
                
                //System.out.println("Mouse clicked.");
                
                
                
                    if(whiteTurn) System.out.println("White Turn");
            
                    /*
                    if(whiteTurn==false)
                    {
                        System.out.println("Black Turn");
                        
                        
                        
                        if(checkKing())
                        {
                        System.out.println("Black King "+checkKing());
                                        computer_move_king();
                                        while(computerAgain==true) computer_move_king();
                        }else{
                                    if(first_check_computer_beat()){}else
                                    {
                                        computer_move();
                                        while(computerAgain==true) computer_move();
                                    }
                        }
                    }
                    */
            }
            //g.drawRect(20+cx*60, 20+cy*60, 60, 60);
           
            
                    if(whiteTurn==false)
                    {
                        System.out.println("Black Turn");
                        
                        //calculate beat table
                        first_check_king_table();
                        
                        if(checkKing())
                        {
                        System.out.println("Black King "+checkKing());
                                        computer_move_king();
                                        
                                        int t=0;
                                        while(computerAgain==true){computer_move_king();t++;if(t>=4) break;}
                                        if(t>=4){computer_move();}
                                        
                        }else{
                                    if(first_check_computer_beat()){}else
                                    {
                                        computer_move();
                                        while(computerAgain==true) computer_move();
                                    }
                        }
                    }
            
            
            this.repaint();
            
            
            Thread.sleep(25);
     }catch(Exception exc){}
     }
    }
    
    public boolean checkKing()
    {
        boolean white_beat=false;
        
        for(Pawn p2:chessboard)
        {
            if(p2.isBlack==false&&p2.alive)
            {
                    if(p2.check_king()==true)
                    {   
                    white_beat=true;
                    return true;
                    }
            }
        }
        
        return white_beat;
    }
    
    public static void first_check_king_table()
    {
        
        
        ctable=new int[][]
        {
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0}
        };
        
        for(Pawn p:chessboard)
        {
            if(p.alive==true)
            {
                if(p.isBlack==false) ctable[p.y][p.x]=1;
                if(p.isBlack==true) ctable[p.y][p.x]=2;
            }
        }
        
        Chess.create_king_table();
        for(Pawn p:chessboard)
        {
            if(p.isBlack==false&&p.alive)
            {
                    //p.check_beat_for_table();
                    p.check_beat_for_table_all_line();
            }
        }
        Chess.show_king_table();
        
    }
    
    public static boolean isKingAt_x_y(int x,int y)
    {
        for(Pawn p2:chessboard)
        {
            if(p2.isBlack&&p2.alive)
            {
                    if(p2.x==x&&p2.y==y&&p2.value.equals("King")){return true;}
                    
            }
        }
        return false;
    }

    public boolean first_check_computer_beat()
    {
        boolean computer_beat=false;
        
        for(Pawn p2:chessboard)
        {
            if(p2.isBlack&&p2.alive)
            {
                    if(p2.check_beat()==true)
                    {   
                    computer_beat=true;
                    return true;
                    }
            }
        }
        
        return computer_beat;
    }
    
    public void computer_move()
    {
    
    computerAgain=false;
    
    Collections.sort(chessboard);    
    
    
    if(whiteTurn==false)
            {
                move_nr++;
                int r=0;
                //if(move_nr<3) r=32-rnd.nextInt(4); else r=rnd.nextInt(4);
                r=rnd.nextInt(3);
                    
                Pawn p=chessboard.get(r);
                
                boolean setPawn=false;
                
                while(setPawn==false)
                {
                    
                    
                    if(p.isBlack&&p.alive)
                    {
                    setPawn=true;
                    System.out.println("Computer check move for: "+p.getColor()+" "+p.value+" "+p.x+" "+p.y);
                    break;
                    }
                    r=rnd.nextInt(chessboard.size());
                    p=chessboard.get(r);
                    
                }
                
                //set move
                boolean setMove=false;
                int rnd_move;
                //if(p.value.equals("Pawn")==false){if(Chess.whiteTurn) Chess.whiteTurn=false; else Chess.whiteTurn=true;}
                //if(p.value.equals("Pawn")==false){computerAgain=true;}
                
                if(p.value.equals("Pawn"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(3);    
                        if(rnd_move==0)
                        {
                            if(ctable[p.y+2][p.x]==0)
                            {
                                setMove=true;
                                if(p.check_move(p.x, p.y+2)){p.move_to(p.x, p.y+2);}
                                
                            }
                        }
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+1][p.x]==0)
                            {
                                setMove=true;
                                if(p.check_move(p.x, p.y+1)){p.move_to(p.x, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+1)){p.move_to(p.x+1, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+1)){p.move_to(p.x-1, p.y+1);}
                                
                            }
                        }
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                    
                    //create_table();
                    //show_table();
                }
                
                if(p.value.equals("Knight"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+2][p.x+1]==0||ctable[p.y+2][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+2)){p.move_to(p.x+1, p.y+2);}
                                
                            }
                        }
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+2][p.x-1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+2)){p.move_to(p.x-1, p.y+2);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+1][p.x+2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+2, p.y+1)){p.move_to(p.x+2, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+1][p.x-2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-2, p.y+1)){p.move_to(p.x-2, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-2][p.x+1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y-2)){p.move_to(p.x+1, p.y-2);}
                                
                            }
                        }
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-2][p.x-1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-2)){p.move_to(p.x-1, p.y-2);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-1][p.x+2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+2, p.y-1)){p.move_to(p.x+2, p.y-1);}
                                
                            }
                        }
                        if(rnd_move==8)
                        {
                            if(ctable[p.y-1][p.x-2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-2, p.y-1)){p.move_to(p.x-2, p.y-1);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                if(computer_pawns_alive==1){
                if(p.value.equals("King"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+1][p.x+0]==0||ctable[p.y+1][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+1)){p.move_to(p.x+0, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+1][p.x+1]==0||ctable[p.y+1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+1)){p.move_to(p.x+1, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+0][p.x+1]==0||ctable[p.y+0][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+0)){p.move_to(p.x+1, p.y+0);}
                                
                            }
                        }
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y-1][p.x+1]==0||ctable[p.y-1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y-1)){p.move_to(p.x+1, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-1][p.x+0]==0||ctable[p.y-1][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-1)){p.move_to(p.x+0, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-1][p.x-1]==0||ctable[p.y-1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-1)){p.move_to(p.x-1, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-0][p.x-1]==0||ctable[p.y-0][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-0)){p.move_to(p.x-1, p.y-0);}
                                
                            }
                        }
                        
                        if(rnd_move==8)
                        {
                            if(ctable[p.y+1][p.x-1]==0||ctable[p.y+1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+1)){p.move_to(p.x-1, p.y+1);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                }
                
                
                if(p.value.equals("Bishop"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(3)+1;    
                        
                        int range=rnd.nextInt(7)+1;    
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+range]==0||ctable[p.y+range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+range)){p.move_to(p.x+range, p.y+range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y-range][p.x+range]==0||ctable[p.y-range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y-range)){p.move_to(p.x+range, p.y-range);}
                            }
                        }
                        
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y-range][p.x-range]==0||ctable[p.y-range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-range)){p.move_to(p.x-range, p.y-range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+range][p.x-range]==0||ctable[p.y+range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y+range)){p.move_to(p.x-range, p.y+range);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                
                if(p.value.equals("Rook"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(3)+1;    
                        
                        int range=rnd.nextInt(7)+1;    
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+0]==0||ctable[p.y+range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+range)){p.move_to(p.x+0, p.y+range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y-range][p.x+0]==0||ctable[p.y-range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-range)){p.move_to(p.x+0, p.y-range);}
                            }
                        }
                        
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y-0][p.x-range]==0||ctable[p.y-0][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-0)){p.move_to(p.x-range, p.y-0);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+0][p.x+range]==0||ctable[p.y+0][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+0)){p.move_to(p.x+range, p.y+0);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
               
                
                if(p.value.equals("Queen"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        
                        int range=rnd.nextInt(2)+1;
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+0]==0||ctable[p.y+range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+range)){p.move_to(p.x+0, p.y+range);}
                                
                            }
                        }
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+range][p.x+range]==0||ctable[p.y+range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+range)){p.move_to(p.x+range, p.y+range);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+0][p.x+range]==0||ctable[p.y+0][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+0)){p.move_to(p.x+range, p.y+0);}
                                
                            }
                        }
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y-range][p.x+range]==0||ctable[p.y-range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y-range)){p.move_to(p.x+range, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-range][p.x+0]==0||ctable[p.y-range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-range)){p.move_to(p.x+0, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-range][p.x-range]==0||ctable[p.y-range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-range)){p.move_to(p.x-range, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-0][p.x-range]==0||ctable[p.y-0][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-0)){p.move_to(p.x-range, p.y-0);}
                                
                            }
                        }
                        
                        if(rnd_move==8)
                        {
                            if(ctable[p.y+range][p.x-range]==0||ctable[p.y+range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y+range)){p.move_to(p.x-range, p.y+range);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                
                
                
            }
    }
    
    //computer move king
    public void computer_move_king()
    {
    
    computerAgain=false;
    
    Collections.sort(chessboard);    
    
    
    if(whiteTurn==false)
            {
                move_nr++;
                int r=0;
                //if(move_nr<3) r=32-rnd.nextInt(4); else r=rnd.nextInt(4);
                r=rnd.nextInt(3);
                    
                Pawn p=chessboard.get(r);
                
                boolean setPawn=false;
                
                
                    
                for(Pawn pawn:chessboard){    
                    
                    if(pawn.isBlack&&pawn.alive&&pawn.value.equals("King"))
                    {
                    setPawn=true;
                    p=pawn;
                    System.out.println("Computer check move for: "+p.getColor()+" "+p.value+" "+p.x+" "+p.y);
                    }
                }
                    
                
                
                //set move
                boolean setMove=false;
                int rnd_move;
                //if(p.value.equals("Pawn")==false){if(Chess.whiteTurn) Chess.whiteTurn=false; else Chess.whiteTurn=true;}
                //if(p.value.equals("Pawn")==false){computerAgain=true;}
                
                if(p.value.equals("Pawn"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(2)+1;    
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+1][p.x]==0)
                            {
                                setMove=true;
                                if(p.check_move(p.x, p.y+1)){p.move_to(p.x, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+1)){p.move_to(p.x+1, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+1)){p.move_to(p.x-1, p.y+1);}
                                
                            }
                        }
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                    
                    //create_table();
                    //show_table();
                }
                
                if(p.value.equals("Knight"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+2][p.x+1]==0||ctable[p.y+2][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+2)){p.move_to(p.x+1, p.y+2);}
                                
                            }
                        }
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+2][p.x-1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+2)){p.move_to(p.x-1, p.y+2);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+1][p.x+2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+2, p.y+1)){p.move_to(p.x+2, p.y+1);}
                                
                            }
                        }
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+1][p.x-2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-2, p.y+1)){p.move_to(p.x-2, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-2][p.x+1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y-2)){p.move_to(p.x+1, p.y-2);}
                                
                            }
                        }
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-2][p.x-1]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-2)){p.move_to(p.x-1, p.y-2);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-1][p.x+2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+2, p.y-1)){p.move_to(p.x+2, p.y-1);}
                                
                            }
                        }
                        if(rnd_move==8)
                        {
                            if(ctable[p.y-1][p.x-2]==0||ctable[p.y+2][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-2, p.y-1)){p.move_to(p.x-2, p.y-1);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                if(p.value.equals("King"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+1][p.x+0]==0||ctable[p.y+1][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+1)&&p.check_beat_table(p.x+0, p.y+1)){p.move_to(p.x+0, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+1][p.x+1]==0||ctable[p.y+1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+1)&&p.check_beat_table(p.x+1, p.y+1)){p.move_to(p.x+1, p.y+1);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+0][p.x+1]==0||ctable[p.y+0][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y+0)&&p.check_beat_table(p.x+1, p.y+0)){p.move_to(p.x+1, p.y+0);}
                                
                            }
                        }
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y-1][p.x+1]==0||ctable[p.y-1][p.x+1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+1, p.y-1)&&p.check_beat_table(p.x+1, p.y-1)){p.move_to(p.x+1, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-1][p.x+0]==0||ctable[p.y-1][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-1)&&p.check_beat_table(p.x+0, p.y-1)){p.move_to(p.x+0, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-1][p.x-1]==0||ctable[p.y-1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-1)&&p.check_beat_table(p.x-1, p.y-1)){p.move_to(p.x-1, p.y-1);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-0][p.x-1]==0||ctable[p.y-0][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y-0)&&p.check_beat_table(p.x-1, p.y-0)){p.move_to(p.x-1, p.y-0);}
                                
                            }
                        }
                        
                        if(rnd_move==8)
                        {
                            if(ctable[p.y+1][p.x-1]==0||ctable[p.y+1][p.x-1]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-1, p.y+1)&&p.check_beat_table(p.x-1, p.y+1)){p.move_to(p.x-1, p.y+1);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                
                
                if(p.value.equals("Bishop"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(3)+1;    
                        
                        int range=rnd.nextInt(7)+1;    
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+range]==0||ctable[p.y+range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+range)){p.move_to(p.x+range, p.y+range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y-range][p.x+range]==0||ctable[p.y-range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y-range)){p.move_to(p.x+range, p.y-range);}
                            }
                        }
                        
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y-range][p.x-range]==0||ctable[p.y-range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-range)){p.move_to(p.x-range, p.y-range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+range][p.x-range]==0||ctable[p.y+range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y+range)){p.move_to(p.x-range, p.y+range);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                
                if(p.value.equals("Rook"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(3)+1;    
                        
                        int range=rnd.nextInt(7)+1;    
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+0]==0||ctable[p.y+range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+range)){p.move_to(p.x+0, p.y+range);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y-range][p.x+0]==0||ctable[p.y-range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-range)){p.move_to(p.x+0, p.y-range);}
                            }
                        }
                        
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y-0][p.x-range]==0||ctable[p.y-0][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-0)){p.move_to(p.x-range, p.y-0);}
                                
                            }
                        }
                        
                        
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y+0][p.x+range]==0||ctable[p.y+0][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+0)){p.move_to(p.x+range, p.y+0);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
               
                
                if(p.value.equals("Queen"))
                {
                    while(setMove==false){
                        rnd_move=rnd.nextInt(7)+1;    
                        
                        int range=rnd.nextInt(2)+1;
                        
                        if(rnd_move==1)
                        {
                            if(ctable[p.y+range][p.x+0]==0||ctable[p.y+range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y+range)){p.move_to(p.x+0, p.y+range);}
                                
                            }
                        }
                        
                        if(rnd_move==2)
                        {
                            if(ctable[p.y+range][p.x+range]==0||ctable[p.y+range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+range)){p.move_to(p.x+range, p.y+range);}
                                
                            }
                        }
                        
                        if(rnd_move==3)
                        {
                            if(ctable[p.y+0][p.x+range]==0||ctable[p.y+0][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y+0)){p.move_to(p.x+range, p.y+0);}
                                
                            }
                        }
                        
                        if(rnd_move==4)
                        {
                            if(ctable[p.y-range][p.x+range]==0||ctable[p.y-range][p.x+range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+range, p.y-range)){p.move_to(p.x+range, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==5)
                        {
                            if(ctable[p.y-range][p.x+0]==0||ctable[p.y-range][p.x+0]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x+0, p.y-range)){p.move_to(p.x+0, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==6)
                        {
                            if(ctable[p.y-range][p.x-range]==0||ctable[p.y-range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-range)){p.move_to(p.x-range, p.y-range);}
                                
                            }
                        }
                        
                        if(rnd_move==7)
                        {
                            if(ctable[p.y-0][p.x-range]==0||ctable[p.y-0][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y-0)){p.move_to(p.x-range, p.y-0);}
                                
                            }
                        }
                        
                        if(rnd_move==8)
                        {
                            if(ctable[p.y+range][p.x-range]==0||ctable[p.y+range][p.x-range]==1)
                            {
                                setMove=true;
                                if(p.check_move(p.x-range, p.y+range)){p.move_to(p.x-range, p.y+range);}
                                
                            }
                        }
                        
                        if(setMove==false) {computerAgain=true;return;}
                    }
                    
                }
                
                
                
                
            }
    }
    
    public void check_mouse()
    {
        if(whiteTurn){
        if(second_select==false){
             //mouse_pressed=true;
             //old_cx=cx;
             //old_cy=cy;
                      
             for(Pawn p:chessboard)
             {
                  if(p.x==cx&&p.y==cy&&p.alive)
                  {
                      pawn_move=p;
                      
                      old_cx=p.x;
                      old_cy=p.y;
                      
                      if(p.isBlack==false){
                      //System.out.println("Check move for White "+p.value);
                        
                      }
                      
                      if(p.isBlack==true){
                      //System.out.println("Check move for Black "+p.value);
                        second_select=false;
                        mouse_clicked=false;
                        whiteTurn=false;
                        return;
                      }
                      
                  }
             }
             second_select=true;
             }
             else{
                 System.out.println("Check move for "+pawn_move.getColor()+" "+pawn_move.value+" from "+pawn_move.x+","+pawn_move.y+" to position "+cx+","+cy);
             
             if(pawn_move.alive&&pawn_move.check_move(cx, cy))
             {
                pawn_move.move_to(cx,cy);
             }
             
             second_select=false;
             
             }
             mouse_clicked=false;
            
            }
        
            
    }
     
    public boolean check_field(int fx,int fy)
    {
            boolean black=true;
               
            for(int x=0;x<8;x++)
            {
            
            for(int y=0;y<8;y++)
            {
                if  (x==fx&&y==fy) return black;
                
                if(black==false){
                //g.drawRect(20+x*60, 20+y*60, 60, 60);
                }
                if(black==true){
                //g.fillRect(20+x*60, 20+y*60, 60, 60);
                }
                if(black)black=false;else black=true;
            }
            if(black)black=false;else black=true;
        }
            
            return black;
    }
    
     public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.fillRect(0, 0, 640, 520);
        
        g.setColor(new Color(190,190,190));
        
        //g.setColor(Color.black);
        
        //draw chessboard
        boolean black=false;
        
        for(int x=0;x<8;x++)
        {
            
            for(int y=0;y<8;y++)
            {
                if(black==false){
                g.drawRect(20+x*60, 20+y*60, 60, 60);
                }
                if(black==true){
                g.fillRect(20+x*60, 20+y*60, 60, 60);
                }
                if(black)black=false;else black=true;
            }
            if(black)black=false;else black=true;
        }
        
        
        //draw field letters and numbers
        g.setColor(Color.black);
        for(int x=0;x<8;x++)
        {
          char c=(char)('a'+x);
            
          g.drawString(""+c, 30+x*60+15, 0*60+13);
          g.drawString(""+c, 30+x*60+15, 500+0*60+13);
        }
        
        for(int y=0;y<8;y++)
        {
          g.drawString(""+(y+1), 0*60+8,40+y*60+15);
          g.drawString(""+(y+1), 480+0*60+28,40+y*60+15);
        }
        
        
        //draw pawns
        //g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 25));
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 25));
        g.setColor(new Color(0,0,0));
        for(Pawn p:chessboard)
        {
            if(p.alive) g.drawString(p.unicode, 20+p.x*60+15, 20+p.y*60+39);
        }
        
        
        
        
        //draw selection square mode
        if(cx>7) cx=7;
        if(cy>7) cy=7;
        
        
        if(second_select==false)
        {
        g.drawRect(20+cx*60, 20+cy*60, 60, 60);
        g.drawRect(21+cx*60, 21+cy*60, 58, 58);
        g.drawRect(22+cx*60, 22+cy*60, 56, 56);
        }
        if(second_select==true)
        {
        g.drawRect(20+old_cx*60, 20+old_cy*60, 60, 60);
        g.drawRect(21+old_cx*60, 21+old_cy*60, 58, 58);
        g.drawRect(22+old_cx*60, 22+old_cy*60, 56, 56);
        
        g.drawRect(20+cx*60, 20+cy*60, 60, 60);
        g.drawRect(21+cx*60, 21+cy*60, 58, 58);
        g.drawRect(22+cx*60, 22+cy*60, 56, 56);
        }
        
        //g.drawString(cx+" "+cy, 20+9*60+15, 20);
        
     }
    
    public static void beat_pawn_at_x_y(int bx,int by)
    {
        for(Pawn p:chessboard)
        {
            if(p.x==bx&&p.y==by&&p.alive) p.alive=false;
        }
        
    }
    
    public static void main(String[] args) {
        Chess c=new Chess();
        c.panel = c;
        c.frame = new JFrame("Mateusz Pawlowski. Computer Chess Program 2024.");
        c.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.frame.getContentPane().add(c.panel);
        c.panel.setSize(300, 300);
        c.frame.setLocation(500, 300);
        c.frame.pack();
        c.frame.show();
        c.thread=new Thread(c);
        c.thread.start();
                
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 520);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getButton()==1)
         {
             //mouse_clicked=true;
        
         }
    }

    @Override
    public void mousePressed(MouseEvent me) {
        mouse_clicked=true;     
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        mouse_clicked=false;
    }

    @Override
    public void mouseEntered(MouseEvent me) {

    }

    @Override
    public void mouseExited(MouseEvent me) {

    }

    @Override
    public void mouseDragged(MouseEvent me) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        this.old_mouse_x=e.getX();
        this.old_mouse_y=e.getY();  
    }
    
    
     
   
}

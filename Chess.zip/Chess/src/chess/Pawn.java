/*
* Mateusz Pawlowski Chess game with computer 2024.
* Computer Chess game programmed in Java. 
*/
package chess;

public class Pawn implements Comparable{

public int x=0;
public int y=0;

//King
//Queen
//Rook
//Bishop
//Knight
//Pawn
public boolean alive=true;

public String value="";

public String unicode="";

public boolean isBlack=false;

public int power=0;

public int calculate_power=0;

public boolean start_pos=true;

Pawn(int x,int y,String value,String isBlack)
{
    if(isBlack.equals("Black")) this.isBlack=true;
    if(isBlack.equals("White")) this.isBlack=false;
    
    this.x=x;
    this.y=y;
    
    this.value=value;
    
    //♚♛♜♝♞♟
    if(this.isBlack){
        if(value.equals("King")) {unicode="♚";power=30;}
        if(value.equals("Queen")) {unicode="♛";power=9;}
        if(value.equals("Rook")) {unicode="♜";power=8;}
        if(value.equals("Bishop")) {unicode="♝";power=7;}
        if(value.equals("Knight")) {unicode="♞";power=6;}
        if(value.equals("Pawn")) {unicode="♟";power=5;}
    }
    
    if(this.isBlack==false){
        if(value.equals("King")) {unicode="♔";power=10;}
        if(value.equals("Queen")) {unicode="♕";power=9;}
        if(value.equals("Rook")) {unicode="♖";power=8;}
        if(value.equals("Bishop")) {unicode="♗";power=7;}
        if(value.equals("Knight")) {unicode="♘";power=6;}
        if(value.equals("Pawn")) {unicode="♙";power=5;}
    }
    //♙♘♗♖♕♔ 
    calculatePower();
}

public void calculatePower()
{
this.calculate_power=Chess.power_table[this.y][this.x]*this.power;
}


public void check_beat_for_table()
{
    if(this.value.equals("Pawn"))
    {
        if(this.y-1>=0)
        {
        if(this.x-1>=0){
            Chess.king_table[this.y-1][this.x-1]=1;
        }
        if(this.x+1<=7){
            Chess.king_table[this.y-1][this.x+1]=1;
        }
        }
    }
    
    if(this.value.equals("Knight"))
    {
        if(this.x-1>=0&&this.y+2<=7){
            Chess.king_table[this.y+2][this.x-1]=1;
        }
        if(this.x+1<=7&&this.y+2<=7){
            Chess.king_table[this.y+2][this.x+1]=1;
        }
        
        if(this.x-2>=0&&this.y+1<=7){
            Chess.king_table[this.y+1][this.x-2]=1;
        }
        if(this.x+2<=7&&this.y+1<=7){
            Chess.king_table[this.y+1][this.x+2]=1;
        }
        
        
        if(this.x-1>=0&&this.y-2>=0){
            Chess.king_table[this.y-2][this.x-1]=1;
        }
        if(this.x+1<=7&&this.y-2>=0){
            Chess.king_table[this.y-2][this.x+1]=1;
        }
        
        if(this.x-2>=0&&this.y-1>=0){
            Chess.king_table[this.y-1][this.x-2]=1;
        }
        if(this.x+2<=7&&this.y-1>=0){
            Chess.king_table[this.y-1][this.x+2]=1;
        }
    }
    
    
    if(this.value.equals("Bishop"))
    {
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    break;
                }
                Chess.king_table[this.y+range][this.x-range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                   Chess.king_table[this.y+range][this.x+range]=1;
                   break;
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        }
    }
    
    
    if(this.value.equals("Rook"))
    {
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    break;
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
                    break;
                }
                Chess.king_table[this.y][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    break;
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    break;
                }
                Chess.king_table[this.y+range][this.x]=1;
            }
        }
    }
    
    //queen moves
    if(this.value.equals("Queen"))
    {
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    break;
                }
                    Chess.king_table[this.y+range][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                    Chess.king_table[this.y+range][this.x+range]=1;
                    break;
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        }
        
        for(int range=1;range<=7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    break;
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        }
        
        for(int range=1;range<=7;range++){
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
                    break;
                }
                    Chess.king_table[this.y][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    break;
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    break;
                }
                Chess.king_table[this.y+range][this.x]=1;
                
            }
        }
    }
    
    if(this.value.equals("King"))
    {
        int range=1;
        
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
        
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        
        
        
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        
        
        
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    
                }
                    Chess.king_table[this.y+range][this.x-range]=1;
            }
        
        
        
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                    Chess.king_table[this.y+range][this.x+range]=1;
                    
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        
        
        
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        
        
        
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
        
                }
                    Chess.king_table[this.y][this.x+range]=1;
            }
        
        
        
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        
        
        
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    
                }
                Chess.king_table[this.y+range][this.x]=1;
                
            }
        
    }
    
}

public void check_beat_for_table_all_line()
{
    if(this.value.equals("Pawn"))
    {
        if(this.y-1>=0)
        {
        if(this.x-1>=0){
            Chess.king_table[this.y-1][this.x-1]=1;
        }
        if(this.x+1<=7){
            Chess.king_table[this.y-1][this.x+1]=1;
        }
        }
    }
    
    if(this.value.equals("Knight"))
    {
        if(this.x-1>=0&&this.y+2<=7){
            Chess.king_table[this.y+2][this.x-1]=1;
        }
        if(this.x+1<=7&&this.y+2<=7){
            Chess.king_table[this.y+2][this.x+1]=1;
        }
        
        if(this.x-2>=0&&this.y+1<=7){
            Chess.king_table[this.y+1][this.x-2]=1;
        }
        if(this.x+2<=7&&this.y+1<=7){
            Chess.king_table[this.y+1][this.x+2]=1;
        }
        
        
        if(this.x-1>=0&&this.y-2>=0){
            Chess.king_table[this.y-2][this.x-1]=1;
        }
        if(this.x+1<=7&&this.y-2>=0){
            Chess.king_table[this.y-2][this.x+1]=1;
        }
        
        if(this.x-2>=0&&this.y-1>=0){
            Chess.king_table[this.y-1][this.x-2]=1;
        }
        if(this.x+2<=7&&this.y-1>=0){
            Chess.king_table[this.y-1][this.x+2]=1;
        }
    }
    
    
    if(this.value.equals("Bishop"))
    {
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    break;
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    break;
                }
                Chess.king_table[this.y+range][this.x-range]=1;
            }
        }
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                   Chess.king_table[this.y+range][this.x+range]=1;
                   break;
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        }
    }
    
    
    if(this.value.equals("Rook"))
    {
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    //break;
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
                    //break;
                }
                Chess.king_table[this.y][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    //break;
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    //break;
                }
                Chess.king_table[this.y+range][this.x]=1;
            }
        }
    }
    
    //queen moves
    if(this.value.equals("Queen"))
    {
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
                    //break;
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    //break;
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    //break;
                }
                    Chess.king_table[this.y+range][this.x-range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                    Chess.king_table[this.y+range][this.x+range]=1;
                    //break;
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        }
        
        for(int range=1;range<=7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    //break;
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        }
        
        for(int range=1;range<=7;range++){
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
                    //break;
                }
                    Chess.king_table[this.y][this.x+range]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    //break;
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        }
        
        for(int range=1;range<7;range++){
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    //break;
                }
                Chess.king_table[this.y+range][this.x]=1;
                
            }
        }
    }
    
    if(this.value.equals("King"))
    {
        int range=1;
        
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2||Chess.ctable[this.y-range][this.x-range]==1)
                {
                    Chess.king_table[this.y-range][this.x-range]=1;
        
                }
                    Chess.king_table[this.y-range][this.x-range]=1;
            }
        
        
        
            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2||Chess.ctable[this.y-range][this.x+range]==1)
                {
                    Chess.king_table[this.y-range][this.x+range]=1;
                    
                }
                    Chess.king_table[this.y-range][this.x+range]=1;
            }
        
        
        
            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2||Chess.ctable[this.y+range][this.x-range]==1)
                {
                    Chess.king_table[this.y+range][this.x-range]=1;
                    
                }
                    Chess.king_table[this.y+range][this.x-range]=1;
            }
        
        
        
            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2||Chess.ctable[this.y+range][this.x+range]==1)
                {
                    Chess.king_table[this.y+range][this.x+range]=1;
                    
                }
                Chess.king_table[this.y+range][this.x+range]=1;
            }
        
        
        
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2||Chess.ctable[this.y][this.x-range]==1)
                {
                    Chess.king_table[this.y][this.x-range]=1;
                    
                }
                Chess.king_table[this.y][this.x-range]=1;
            }
        
        
        
            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2||Chess.ctable[this.y][this.x+range]==1)
                {
                    Chess.king_table[this.y][this.x+range]=1;
        
                }
                    Chess.king_table[this.y][this.x+range]=1;
            }
        
        
        
            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2||Chess.ctable[this.y-range][this.x]==1)
                {
                    Chess.king_table[this.y-range][this.x]=1;
                    
                }
                Chess.king_table[this.y-range][this.x]=1;
            }
        
        
        
            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2||Chess.ctable[this.y+range][this.x]==1)
                {
                    Chess.king_table[this.y+range][this.x]=1;
                    
                }
                Chess.king_table[this.y+range][this.x]=1;
                
            }
        
    }
    
}

//
public boolean check_beat()
{
    boolean canBeat=false;
    
    if(this.value.equals("Pawn"))
    {
        if(this.y+1<=7)
        {
        if(this.x-1>=0){
            if(Chess.ctable[this.y+1][this.x-1]==1){Chess.beat_pawn_at_x_y(this.x-1, this.y+1);this.move_to(this.x-1, this.y+1);return true;}
        }
        if(this.x+1<=7){
            if(Chess.ctable[this.y+1][this.x+1]==1){Chess.beat_pawn_at_x_y(this.x+1, this.y+1);this.move_to(this.x+1, this.y+1);return true;}
        }
        }
    }
    
    if(this.value.equals("Knight"))
    {
        if(this.x-1>=0&&this.y+2<=7){
            if(Chess.ctable[this.y+2][this.x-1]==1){Chess.beat_pawn_at_x_y(this.x-1, this.y+2);this.move_to(this.x-1, this.y+2);return true;}
        }
        if(this.x+1<=7&&this.y+2<=7){
            if(Chess.ctable[this.y+2][this.x+1]==1){Chess.beat_pawn_at_x_y(this.x+1, this.y+2);this.move_to(this.x+1, this.y+2);return true;}
        }
        
        if(this.x-2>=0&&this.y+1<=7){
            if(Chess.ctable[this.y+1][this.x-2]==1){Chess.beat_pawn_at_x_y(this.x-2, this.y+1);this.move_to(this.x-2, this.y+1);return true;}
        }
        if(this.x+2<=7&&this.y+1<=7){
            if(Chess.ctable[this.y+1][this.x+2]==1){Chess.beat_pawn_at_x_y(this.x+2, this.y+1);this.move_to(this.x+2, this.y+1);return true;}
        }
        
        
        if(this.x-1>=0&&this.y-2>=0){
            if(Chess.ctable[this.y-2][this.x-1]==1){Chess.beat_pawn_at_x_y(this.x-1, this.y-2);this.move_to(this.x-1, this.y-2);return true;}
        }
        if(this.x+1<=7&&this.y-2>=0){
            if(Chess.ctable[this.y-2][this.x+1]==1){Chess.beat_pawn_at_x_y(this.x+1, this.y-2);this.move_to(this.x+1, this.y-2);return true;}
        }
        
        if(this.x-2>=0&&this.y-1>=0){
            if(Chess.ctable[this.y-1][this.x-2]==1){Chess.beat_pawn_at_x_y(this.x-2, this.y-1);this.move_to(this.x-2, this.y-1);return true;}
        }
        if(this.x+2<=7&&this.y-1>=0){
            if(Chess.ctable[this.y-1][this.x+2]==1){Chess.beat_pawn_at_x_y(this.x+2, this.y-1);this.move_to(this.x+2, this.y-1);return true;}
        }
    }
    
    if(this.value.equals("Bishop"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y-range);this.move_to(this.x-range, this.y-range);return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y-range);this.move_to(this.x+range, this.y-range);return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y+range);this.move_to(this.x-range, this.y+range);return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y+range);this.move_to(this.x+range, this.y+range);return true;}
                }
            }
        }
    }
    
    
    if(this.value.equals("Rook"))
    {
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y);this.move_to(this.x-range, this.y);return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y);this.move_to(this.x+range, this.y);return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y-range);this.move_to(this.x, this.y-range);return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y+range);this.move_to(this.x, this.y+range);return true;}
                }
            }
        }
    }
    
    //queen moves
     if(this.value.equals("Queen"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y-range);this.move_to(this.x-range, this.y-range);return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y-range);this.move_to(this.x+range, this.y-range);return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y+range);this.move_to(this.x-range, this.y+range);return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y+range);this.move_to(this.x+range, this.y+range);return true;}
                }
            }
        }
    
    
    
    
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y);this.move_to(this.x-range, this.y);return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y);this.move_to(this.x+range, this.y);return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y-range);this.move_to(this.x, this.y-range);return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y+range);this.move_to(this.x, this.y+range);return true;}
                }
            }
        }
    }
    
    //king moves
    //queen moves
     if(this.value.equals("King"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        int range=1;
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==2){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y-range);this.move_to(this.x-range, this.y-range);return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==2){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y-range);this.move_to(this.x+range, this.y-range);return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==2){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y+range);this.move_to(this.x-range, this.y+range);return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==2){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y+range);this.move_to(this.x+range, this.y+range);return true;}
                }
            }
        
    
    
    
    
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==2){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==1){Chess.beat_pawn_at_x_y(this.x-range, this.y);this.move_to(this.x-range, this.y);return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==2){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==1){Chess.beat_pawn_at_x_y(this.x+range, this.y);this.move_to(this.x+range, this.y);return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==2){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y-range);this.move_to(this.x, this.y-range);return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==2){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==1){Chess.beat_pawn_at_x_y(this.x, this.y+range);this.move_to(this.x, this.y+range);return true;}
                }
            }
        
    }
    
    return canBeat;
}

// check King
public boolean check_king()
{
    boolean canBeat=false;
    
    
    
    if(this.value.equals("Pawn"))
    {
        if(this.y-1>=0)
        {
        if(this.x-1>=0){
            if(Chess.ctable[this.y-1][this.x-1]==2){if(Chess.isKingAt_x_y(this.x-1, this.y-1)) return true;}
        }
        if(this.x+1<=7){
            if(Chess.ctable[this.y-1][this.x+1]==2){if(Chess.isKingAt_x_y(this.x+1, this.y-1)) return true;}
        }
        }
    }
    
    if(this.value.equals("Knight"))
    {
        if(this.x-1>=0&&this.y+2<=7){
            if(Chess.ctable[this.y+2][this.x-1]==2){if(Chess.isKingAt_x_y(this.x-1, this.y+2)) return true;}
        }
        if(this.x+1<=7&&this.y+2<=7){
            if(Chess.ctable[this.y+2][this.x+1]==2){if(Chess.isKingAt_x_y(this.x+1, this.y+2)) return true;}
        }
        
        if(this.x-2>=0&&this.y+1<=7){
            if(Chess.ctable[this.y+1][this.x-2]==2){if(Chess.isKingAt_x_y(this.x-2, this.y+1)) return true;}
        }
        if(this.x+2<=7&&this.y+1<=7){
            if(Chess.ctable[this.y+1][this.x+2]==2){if(Chess.isKingAt_x_y(this.x+2, this.y+1)) return true;}
        }
        
        
        if(this.x-1>=0&&this.y-2>=0){
            if(Chess.ctable[this.y-2][this.x-1]==2){if(Chess.isKingAt_x_y(this.x-1, this.y-2)) return true;}
        }
        if(this.x+1<=7&&this.y-2>=0){
            if(Chess.ctable[this.y-2][this.x+1]==2){if(Chess.isKingAt_x_y(this.x+1, this.y-2)) return true;}
        }
        
        if(this.x-2>=0&&this.y-1>=0){
            if(Chess.ctable[this.y-1][this.x-2]==2){if(Chess.isKingAt_x_y(this.x-2, this.y-1)) return true;}
        }
        if(this.x+2<=7&&this.y-1>=0){
            if(Chess.ctable[this.y-1][this.x+2]==2){if(Chess.isKingAt_x_y(this.x+2, this.y-1)) return true;}
        }
    }
    
    if(this.value.equals("Bishop"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==1){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y-range)) return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==1){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==1){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y+range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==1){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y+range)) return true;}
                }
            }
        }
    }
    
    
    if(this.value.equals("Rook"))
    {
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==1){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y)) return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==1){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y)) return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==1){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==1){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y+range)) return true;}
                }
            }
        }
    }
    
    //queen moves
     if(this.value.equals("Queen"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        for(int range=1;range<7;range++){
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==1){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y-range)) return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==1){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==1){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y+range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==1){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y+range)) return true;}
                }
            }
        }
    
    
    
    
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        for(int range=1;range<7;range++){
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==1){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y)) return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==1){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y)) return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==1){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==1){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y+range)) return true;}
                }
            }
        }
    }
    
    //king moves
    //queen moves
     if(this.value.equals("King"))
    {
        boolean pawnAtLine7=false;
        boolean pawnAtLine9=false;
        boolean pawnAtLine1=false;
        boolean pawnAtLine3=false;
        
        int range=1;
            if(this.y-range>=0&&this.x-range>=0){
                if(Chess.ctable[this.y-range][this.x-range]==1){pawnAtLine7=true;}
                if(pawnAtLine7==false){
                    if(Chess.ctable[this.y-range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y-range)) return true;}
                }
            }

            if(this.y-range>=0&&this.x+range<=7){
                if(Chess.ctable[this.y-range][this.x+range]==1){pawnAtLine9=true;}
                if(pawnAtLine9==false){
                    if(Chess.ctable[this.y-range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x-range>=0){
                if(Chess.ctable[this.y+range][this.x-range]==1){pawnAtLine1=true;}
                if(pawnAtLine1==false){
                    if(Chess.ctable[this.y+range][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y+range)) return true;}
                }
            }

            if(this.y+range<=7&&this.x+range<=7){
                if(Chess.ctable[this.y+range][this.x+range]==1){pawnAtLine3=true;}
                if(pawnAtLine3==false){
                    if(Chess.ctable[this.y+range][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y+range)) return true;}
                }
            }
        
    
    
    
    
        boolean pawnAtLine4=false;
        boolean pawnAtLine6=false;
        boolean pawnAtLine8=false;
        boolean pawnAtLine2=false;
        
        
            if(this.x-range>=0){
                if(Chess.ctable[this.y][this.x-range]==1){pawnAtLine4=true;}
                if(pawnAtLine4==false){
                    if(Chess.ctable[this.y][this.x-range]==2){if(Chess.isKingAt_x_y(this.x-range, this.y)) return true;}
                }
            }

            if(this.x+range<=7){
                if(Chess.ctable[this.y][this.x+range]==1){pawnAtLine6=true;}
                if(pawnAtLine6==false){
                    if(Chess.ctable[this.y][this.x+range]==2){if(Chess.isKingAt_x_y(this.x+range, this.y)) return true;}
                }
            }

            if(this.y-range>=0){
                if(Chess.ctable[this.y-range][this.x]==1){pawnAtLine8=true;}
                if(pawnAtLine8==false){
                    if(Chess.ctable[this.y-range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y-range)) return true;}
                }
            }

            if(this.y+range<=7){
                if(Chess.ctable[this.y+range][this.x]==1){pawnAtLine2=true;}
                if(pawnAtLine2==false){
                    if(Chess.ctable[this.y+range][this.x]==2){if(Chess.isKingAt_x_y(this.x, this.y+range)) return true;}
                }
            }
        
    }
     
    return canBeat;
}

public boolean check_beat_table(int to_x,int to_y)
{
    if(Chess.king_table[to_y][to_x]==0) return true; else return false;
}

public boolean check_move(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    if(this.value.equals("Pawn")){can_move_to=check_move_for_pawn(to_x,to_y);}
    if(this.value.equals("King")){can_move_to=check_move_for_king(to_x,to_y);}
    if(this.value.equals("Knight")){can_move_to=check_move_for_knight(to_x,to_y);}
    if(this.value.equals("Rook")){can_move_to=check_move_for_rook(to_x,to_y);}
    
    if(this.value.equals("Queen"))
    {
        if(check_move_for_rook(to_x,to_y)==true||check_move_for_bishop(to_x,to_y)==true) can_move_to=true;
    }
    
    if(this.value.equals("Bishop")){can_move_to=check_move_for_bishop(to_x,to_y);}
    
    //can_move_to=true;
    return can_move_to;
}

public boolean check_move_for_rook(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    int vx=to_x-this.x;
    int vy=to_y-this.y;
    //8 0 -1
    //2 0 1
    
    //4 -1 0
    //6 1 0
    System.out.println("vx="+vx);
    System.out.println("vy="+vy);
    
    
    boolean block=false;
    
    if(vx==0&&vy<=-1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y-range][this.x]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x&&to_y==this.y-range)
                {
                    System.out.println(""+(int)(this.x)+""+(int)(this.y-range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    
    }
    
    
    
    else if(vx==0&&vy>=1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y+range][this.x]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x&&to_y==this.y+range)
                {
                    System.out.println(""+(int)(this.x)+""+(int)(this.y+range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
    else if(vx<=-1&&vy==0)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y][this.x-range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x-range&&to_y==this.y)
                {
                    System.out.println(""+(int)(this.x-range)+""+(int)(this.y));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
    else if(vx>=1&&vy==0)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y][this.x+range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x+range&&to_y==this.y)
                {
                    System.out.println(""+(int)(this.x+range)+""+(int)(this.y));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
   
   
    return can_move_to;
}

public boolean check_move_for_bishop(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    int vx=to_x-this.x;
    int vy=to_y-this.y;
    //7 -1 -1
    //9 1 -1
    
    //1 -1 1
    //3 1 1
    boolean block=false;
    
    if(vx<=-1&&vy<=-1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y-range][this.x-range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x-range&&to_y==this.y-range)
                {
                    System.out.println(""+(int)(this.x-range)+""+(int)(this.y-range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    
    }
    
    
    
    else if(vx>=1&&vy<=-1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y-range][this.x+range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x+range&&to_y==this.y-range)
                {
                    System.out.println(""+(int)(this.x+range)+""+(int)(this.y-range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
    else if(vx<=-1&&vy>=1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y+range][this.x-range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x-range&&to_y==this.y+range)
                {
                    System.out.println(""+(int)(this.x-range)+""+(int)(this.y+range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
    else if(vx>=1&&vy>=1)
    {
    
            for(int range=1;range<8;range++){
                
                if(Chess.ctable[this.y+range][this.x+range]!=0) block=true;
                    System.out.println("range="+range);
                if(to_x==this.x+range&&to_y==this.y+range)
                {
                    System.out.println(""+(int)(this.x+range)+""+(int)(this.y+range));
                    if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
                    
                    if(this.isBlack==false) if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    if(this.isBlack==true) if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
                    
                    break;
                }
                if(block) {can_move_to=false;break;}
            }
            
            System.out.println("vx="+vx);
            System.out.println("vy="+vy);
    }
    
   
   
    return can_move_to;
}

public boolean check_move_for_knight(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    if(this.isBlack==false)
    {
            if(to_x-1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            
            
            
           
            
            
            
    } 
    
    if(this.isBlack==true)
    {
            if(to_x-1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y-2)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+2==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y+2)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+2==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
    } 
    
    return can_move_to;
}

public boolean check_move_for_king(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    if(this.isBlack==false)
    {
            if(to_x-1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
           
            
            if(to_x-1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
    } 
    
    if(this.isBlack==true)
    {
            if(to_x-1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x-1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x+1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
           
            
            if(to_x-1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y+1)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x-1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x+1==this.x&&to_y==this.y)
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
    } 
    
    return can_move_to;
}

public boolean check_move_for_pawn(int to_x,int to_y)
{
    boolean can_move_to=false;
    
    if(this.isBlack==false)
    {
            if(start_pos==true)
            {
                if(to_x==this.x&&to_y==this.y-2)
                {
                    if(Chess.ctable[to_y][to_x]==0&&Chess.ctable[to_y+1][to_x]==0){can_move_to=true;}
                }
            }
            
            if(to_x==this.x&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==this.x-1&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==this.x+1&&to_y==this.y-1)
            {
                if(Chess.ctable[to_y][to_x]==2){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
    } 
    
    if(this.isBlack==true)
    {
            if(start_pos==true)
            {
                if(to_x==this.x&&to_y==this.y+2)
                {
                    if(Chess.ctable[to_y][to_x]==0&&Chess.ctable[to_y-1][to_x]==0){can_move_to=true;}
                }
            }
            
            if(to_x==this.x&&to_y==(this.y+1))
            {
                if(Chess.ctable[to_y][to_x]==0){can_move_to=true;}
            }
            
            if(to_x==(this.x-1)&&to_y==(this.y+1))
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
            
            if(to_x==(this.x+1)&&to_y==(this.y+1))
            {
                if(Chess.ctable[to_y][to_x]==1){can_move_to=true;Chess.beat_pawn_at_x_y(to_x, to_y);}
            }
    }
    
    return can_move_to;
}

public void move_to(int x,int y)
{

this.x=x;
this.y=y;

start_pos=false;

calculatePower();

if(this.isBlack)
{
    //Chess.whiteTurn=true;
    Chess.blackMoves=true;
    Chess.whiteMoves=false;
}

if(this.isBlack==false)
{
    //Chess.whiteTurn=false;
    Chess.blackMoves=false;
    Chess.whiteMoves=true;
}

if(Chess.whiteTurn) Chess.whiteTurn=false; else Chess.whiteTurn=true;
}

public String getColor()
{
String pawn_color;
if (this.isBlack==true) pawn_color="Black"; else pawn_color="White";
return pawn_color;
}

    public int compareTo(Object o) {
        int wynik=-1;
        if (((Pawn)o).calculate_power>(this.calculate_power)) wynik=1;
        return wynik;
    }

}


/*
        //black pawns
        g.drawString("♜", 0*60+15, 39);
        g.drawString("♞", 1*60+15, 39);
        g.drawString("♝", 2*60+15, 39);
        g.drawString("♛", 3*60+15, 39);
        g.drawString("♚", 4*60+15, 39);
        g.drawString("♝", 5*60+15, 39);
        g.drawString("♞", 6*60+15, 39);
        g.drawString("♜", 7*60+15, 39);
        //♙♘♗♖♕♔ ♚♛♜♝♞♟
        g.drawString("♟", 0*60+15, 1*60+39);
        g.drawString("♟", 1*60+15, 1*60+39);
        g.drawString("♟", 2*60+15, 1*60+39);
        g.drawString("♟", 3*60+15, 1*60+39);
        g.drawString("♟", 4*60+15, 1*60+39);
        g.drawString("♟", 5*60+15, 1*60+39);
        g.drawString("♟", 6*60+15, 1*60+39);
        g.drawString("♟", 7*60+15, 1*60+39);
        
        //white pawns
        g.drawString("♖", 0*60+15, 7*60+39);
        g.drawString("♘", 1*60+15, 7*60+39);
        g.drawString("♗", 2*60+15, 7*60+39);
        g.drawString("♕", 3*60+15, 7*60+39);
        g.drawString("♔", 4*60+15, 7*60+39);
        g.drawString("♗", 5*60+15, 7*60+39);
        g.drawString("♘", 6*60+15, 7*60+39);
        g.drawString("♖", 7*60+15, 7*60+39);
        
        g.drawString("♙", 0*60+15, 6*60+39);
        g.drawString("♙", 1*60+15, 6*60+39);
        g.drawString("♙", 2*60+15, 6*60+39);
        g.drawString("♙", 3*60+15, 6*60+39);
        g.drawString("♙", 4*60+15, 6*60+39);
        g.drawString("♙", 5*60+15, 6*60+39);
        g.drawString("♙", 6*60+15, 6*60+39);
        g.drawString("♙", 7*60+15, 6*60+39);
        
        */